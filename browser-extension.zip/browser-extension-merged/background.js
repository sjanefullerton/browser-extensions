// ---------------------------------------------------------------------------
// State tracked for download renaming
// ---------------------------------------------------------------------------
let currentEventName = "Unknown_Event";
let currentBreakdownName = "__simple__";
let currentExpId = "000000";

const ALIEN_ATTACK_ID = '7309522962';

chrome.downloads.onDeterminingFilename.addListener((item, suggest) => {
  if (item.url.includes('roblox.com')) {
    const folder = `roblox-exports/${currentExpId}`;
    let filename = item.filename;

    if (filename.includes('CustomEventsV2')) {
      if (currentBreakdownName && currentBreakdownName !== '__simple__') {
        // Alien Attack breakdown mode: custom-events/<EventName>/<EventName>_<Breakdown>.csv
        filename = `custom-events/${currentEventName}/${currentEventName}_${currentBreakdownName}.csv`;
      } else {
        // General mode: custom-events/<EventName>.csv
        filename = `custom-events/${currentEventName}.csv`;
      }
    }

    suggest({ filename: `${folder}/${filename}` });
  }
});

// ---------------------------------------------------------------------------
// Message router
// ---------------------------------------------------------------------------
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "START_EXPORT") {
    executeAutomation(request.config);
  } else if (request.action === "SET_EVENT_NAME") {
    currentEventName     = request.eventName;
    currentBreakdownName = request.breakdownName ?? '__simple__';
    currentExpId         = request.expId;
  }
});

// ---------------------------------------------------------------------------
// Main orchestrator
// ---------------------------------------------------------------------------
async function executeAutomation(config) {
  const analyticsPages    = ['retention', 'engagement', 'acquisition', 'audience', 'economy', 'funnels'];
  const monetizationPages = ['overview', 'developer-products', 'passes', 'avatar-items',
                              'immersive-ads', 'subscriptions', 'creator-rewards'];

  for (let i = 0; i < config.ids.length; i++) {
    const id = config.ids[i];

    // 30s cooldown between experiences to let the browser settle
    if (i > 0) {
      console.log("Cooling down 30s before next experience...");
      await new Promise(res => setTimeout(res, 30000));
    }
    currentExpId = id;

    if (config.doAnalytics) {
      for (const page of analyticsPages) {
        const url = `https://create.roblox.com/dashboard/creations/experiences/${id}/analytics/${page}`;
        await runInTab(url, id, scrapeStandardCSV);
      }
    }

    if (config.doCustom) {
      if (id === ALIEN_ATTACK_ID) {
        // Alien Attack: full breakdown mode — 10 CSVs per event
        await runCustomBreakdownMode(id);
      } else {
        // All other experiences: general mode — one CSV per event, no breakdowns
        const url = `https://create.roblox.com/dashboard/creations/experiences/${id}/analytics/custom`;
        await runInTab(url, id, scrapeCustomEventsGeneral);
      }
    }

    if (config.doMonetization) {
      for (const page of monetizationPages) {
        const url = `https://create.roblox.com/dashboard/creations/experiences/${id}/monetization/${page}`;
        await runInTab(url, id, scrapeStandardCSV);
      }
    }
  }

  console.log("ALL EXPORTS COMPLETE");
}

// ---------------------------------------------------------------------------
// Alien Attack breakdown mode
// ---------------------------------------------------------------------------
async function runCustomBreakdownMode(expId) {
  const breakdowns = [
    { name: 'None',           suffix: '' },
    { name: 'CustomField1',   suffix: '&breakdown=CustomField1' },
    { name: 'CustomField2',   suffix: '&breakdown=CustomField2' },
    { name: 'CustomField3',   suffix: '&breakdown=CustomField3' },
    { name: 'AgeGroup',       suffix: '&breakdown=AgeGroup' },
    { name: 'Gender',         suffix: '&breakdown=Gender' },
    { name: 'OS',             suffix: '&breakdown=OperatingSystem' },
    { name: 'Platform',       suffix: '&breakdown=Platform' },
    { name: 'PayerStatus',    suffix: '&breakdown=PayerStatus' },
    { name: 'NewVsReturning', suffix: '&breakdown=NewVsReturning' }
  ];

  const baseUrl = `https://create.roblox.com/dashboard/creations/experiences/${expId}/analytics/custom?annotation=Announcement`;
  const eventNames = await runInTabWithResult(baseUrl, expId, scrapeEventNames);

  if (!eventNames || eventNames.length === 0) {
    console.warn("No custom events found for", expId);
    return;
  }

  for (const eventName of eventNames) {
    for (const breakdown of breakdowns) {
      currentEventName     = eventName;
      currentBreakdownName = breakdown.name;
      currentExpId         = expId;

      const url =
        `https://create.roblox.com/dashboard/creations/experiences/${expId}` +
        `/analytics/custom?filter_AggregationType=Sum` +
        `&filter_CustomEventName=${encodeURIComponent(eventName)}` +
        `&annotation=PlaceVersion&annotation=ConfigVersion` +
        `&granularity=Daily${breakdown.suffix}`;

      await runInTabPolling(url);
    }
  }
}

// ---------------------------------------------------------------------------
// Tab helpers
// ---------------------------------------------------------------------------

/** Analytics/monetization and general custom events: navigate then flat 8s wait. */
async function runInTab(url, expId, scriptFunc) {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  await chrome.tabs.update(tab.id, { url });

  return new Promise((resolve) => {
    chrome.tabs.onUpdated.addListener(function onUpdate(tabId, info) {
      if (tabId === tab.id && info.status === 'complete') {
        chrome.tabs.onUpdated.removeListener(onUpdate);
        setTimeout(async () => {
          await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            func: scriptFunc,
            args: [expId]
          });
          resolve();
        }, 8000);
      }
    });
  });
}

/**
 * Alien Attack breakdown pages only.
 * Poll every 100ms (max 90s) until download button visible, click it,
 * then wait for the download to fully complete before returning.
 */
async function runInTabPolling(url) {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  await chrome.tabs.update(tab.id, { url });

  await new Promise((resolve) => {
    chrome.tabs.onUpdated.addListener(function onUpdate(tabId, info) {
      if (tabId === tab.id && info.status === 'complete') {
        chrome.tabs.onUpdated.removeListener(onUpdate);
        resolve();
      }
    });
  });

  const deadline = Date.now() + 90000;
  let found = false;
  while (Date.now() < deadline) {
    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => {
        const btn = document.querySelector('[data-testid="chart-download-button"]');
        return !!(btn && btn.offsetParent !== null);
      }
    });
    if (results?.[0]?.result) { found = true; break; }
    await new Promise(res => setTimeout(res, 100));
  }

  if (!found) {
    console.warn('Download button did not appear within 90s, skipping:', url);
    return;
  }

  // Listen for download start BEFORE clicking so we don't miss it
  const downloadStarted = new Promise((resolve) => {
    chrome.downloads.onCreated.addListener(function onCreated(item) {
      chrome.downloads.onCreated.removeListener(onCreated);
      resolve(item.id);
    });
  });

  await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: () => document.querySelector('[data-testid="chart-download-button"]')?.click()
  });

  // Wait for download to fully complete before moving on
  const downloadId = await downloadStarted;
  await new Promise((resolve) => {
    chrome.downloads.onChanged.addListener(function onChanged(delta) {
      if (delta.id !== downloadId) return;
      if (delta.state && (delta.state.current === 'complete' || delta.state.current === 'interrupted')) {
        chrome.downloads.onChanged.removeListener(onChanged);
        resolve();
      }
    });
  });
}

/** Navigate, poll for Custom Event Name label, run scriptFunc, return result. */
async function runInTabWithResult(url, expId, scriptFunc) {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  await chrome.tabs.update(tab.id, { url });

  await new Promise((resolve) => {
    chrome.tabs.onUpdated.addListener(function onUpdate(tabId, info) {
      if (tabId === tab.id && info.status === 'complete') {
        chrome.tabs.onUpdated.removeListener(onUpdate);
        resolve();
      }
    });
  });

  const deadline = Date.now() + 90000;
  while (Date.now() < deadline) {
    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => !!(Array.from(document.querySelectorAll('label'))
        .find(el => el.textContent.includes('Custom Event Name')))
    });
    if (results?.[0]?.result) break;
    await new Promise(res => setTimeout(res, 100));
  }

  const results = await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: scriptFunc,
    args: [expId]
  });
  return results?.[0]?.result ?? [];
}

// ---------------------------------------------------------------------------
// Page scripts (injected)
// ---------------------------------------------------------------------------

function scrapeStandardCSV() {
  const buttons = document.querySelectorAll(
    '[data-testid="chart-export-button"], [aria-label*="Export"], [data-testid="chart-download-button"]'
  );
  buttons.forEach(btn => btn.click());
}

/** General mode: click through dropdown, one CSV per event, no breakdowns. */
async function scrapeCustomEventsGeneral(expId) {
  const wait = (ms) => new Promise(res => setTimeout(res, ms));

  const label = Array.from(document.querySelectorAll('label'))
    .find(el => el.textContent.includes('Custom Event Name'));
  if (!label) return;

  const openButton = label.parentElement.querySelector('button[aria-label="Open"]');
  if (!openButton) return;

  openButton.click();
  await wait(1500);

  const options = Array.from(document.querySelectorAll('[role="listbox"] li'));
  for (let i = 0; i < options.length; i++) {
    const currentOptions = Array.from(document.querySelectorAll('[role="listbox"] li'));
    const eventName = currentOptions[i].innerText.trim().replace(/\s+/g, '_');

    currentOptions[i].click();
    await wait(4000);

    chrome.runtime.sendMessage({
      action: "SET_EVENT_NAME",
      eventName,
      breakdownName: '__simple__',
      expId
    });

    const downloadBtn = document.querySelector('[data-testid="chart-download-button"]');
    if (downloadBtn) downloadBtn.click();

    await wait(1500);
    document.querySelector('button[aria-label="Open"]')?.click();
    await wait(1000);
  }
}

/** Alien Attack mode: scrape event names from dropdown and return them. */
async function scrapeEventNames() {
  const wait = (ms) => new Promise(res => setTimeout(res, ms));

  const label = Array.from(document.querySelectorAll('label'))
    .find(el => el.textContent.includes('Custom Event Name'));
  if (!label) return [];

  const openButton = label.parentElement.querySelector('button[aria-label="Open"]');
  if (!openButton) return [];

  openButton.click();
  await wait(1500);

  const options = Array.from(document.querySelectorAll('[role="listbox"] li'));
  const names = options.map(o => o.innerText.trim().replace(/\s+/g, '_'));

  document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
  await wait(500);

  return names;
}
