document.getElementById('startBtn').addEventListener('click', () => {
  const ids = document.getElementById('ids').value.split(',').map(s => s.trim()).filter(Boolean);
  const customMode = document.querySelector('input[name="customMode"]:checked').value;

  const config = {
    ids,
    doAnalytics: document.getElementById('analytics').checked,
    doMonetization: document.getElementById('monetization').checked,
    doCustom: document.getElementById('custom').checked,
    customMode // 'simple' or 'breakdown'
  };

  chrome.runtime.sendMessage({ action: "START_EXPORT", config });
  document.getElementById('status').innerText = "Running… check the Roblox tab.";
});
