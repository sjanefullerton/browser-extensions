// ---------------------------------------------------------------------------
// State tracked for download renaming
// ---------------------------------------------------------------------------
let currentEventName = "Unknown_Event";
let currentBreakdownName = "None";
let currentExpId = "000000";

// Rename downloads as they begin so files land in the right folder/name
chrome.downloads.onDeterminingFilename.addListener((item, suggest) => {
  if (item.url.includes('roblox.com')) {
    const folder = `roblox-exports/${currentExpId}`;
    let filename = item.filename;

    if (filename.includes('CustomEventsV2')) {
      // breakdown mode: custom-events/<EventName>/<EventName>_<Breakdown>.csv
      // simple mode:    custom-events/<EventName>.csv
      if (currentBreakdownName && currentBreakdownName !== '__simple__') {
        filename = `custom-events/${currentEventName}/${currentEventName}_${currentBreakdownName}.csv`;
      } else {
        filename = `custom-events/${currentEventName}.csv`;
      }
    }

    suggest({ filename: `${folder}/${filename}` });
  }
});

// ---------------------------------------------------------------------------
// Message router
// ---------------------------------------------------------------------------
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "START_EXPORT") {
    executeAutomation(request.config);
  } else if (request.action === "SET_EVENT_NAME") {
    currentEventName    = request.eventName;
    currentBreakdownName = request.breakdownName ?? '__simple__';
    currentExpId        = request.expId;
  }
});

// ---------------------------------------------------------------------------
// Main orchestrator
// ---------------------------------------------------------------------------
async function executeAutomation(config) {
  const analyticsPages    = ['retention', 'engagement', 'acquisition', 'audience', 'economy', 'funnels'];
  const monetizationPages = ['overview', 'developer-products', 'passes', 'avatar-items',
                              'immersive-ads', 'subscriptions', 'creator-rewards'];

  for (const id of config.ids) {
    currentExpId = id;

    if (config.doAnalytics) {
      for (const page of analyticsPages) {
        const url = `https://create.roblox.com/dashboard/creations/experiences/${id}/analytics/${page}`;
        await runInTab(url, id, scrapeStandardCSV);
      }
    }

    if (config.doCustom) {
      if (config.customMode === 'breakdown') {
        // Alien Attack mode — navigate to each breakdown URL directly
        await runCustomBreakdownMode(id);
      } else {
        // Original simple mode — click through the dropdown
        const url = `https://create.roblox.com/dashboard/creations/experiences/${id}/analytics/custom`;
        await runInTab(url, id, scrapeCustomEventsSimple);
      }
    }

    if (config.doMonetization) {
      for (const page of monetizationPages) {
        const url = `https://create.roblox.com/dashboard/creations/experiences/${id}/monetization/${page}`;
        await runInTab(url, id, scrapeStandardCSV);
      }
    }
  }

  console.log("ALL EXPORTS COMPLETE");
}

// ---------------------------------------------------------------------------
// Breakdown mode (roblox-export-manual.js equivalent)
// Discovers event names from the dropdown, then navigates to each
// breakdown URL directly and clicks the download button.
// ---------------------------------------------------------------------------
async function runCustomBreakdownMode(expId) {
  const breakdowns = [
    { name: 'None',            suffix: '' },
    { name: 'CustomField1',    suffix: '&breakdown=CustomField1' },
    { name: 'CustomField2',    suffix: '&breakdown=CustomField2' },
    { name: 'CustomField3',    suffix: '&breakdown=CustomField3' },
    { name: 'AgeGroup',        suffix: '&breakdown=AgeGroup' },
    { name: 'Gender',          suffix: '&breakdown=Gender' },
    { name: 'OS',              suffix: '&breakdown=OperatingSystem' },
    { name: 'Platform',        suffix: '&breakdown=Platform' },
    { name: 'PayerStatus',     suffix: '&breakdown=PayerStatus' },
    { name: 'NewVsReturning',  suffix: '&breakdown=NewVsReturning' }
  ];

  // Step 1: navigate to the custom page and scrape the event name list
  const baseUrl = `https://create.roblox.com/dashboard/creations/experiences/${expId}/analytics/custom?annotation=Announcement`;
  const eventNames = await runInTabWithResult(baseUrl, expId, scrapeEventNames);

  if (!eventNames || eventNames.length === 0) {
    console.warn("No custom events found for", expId);
    return;
  }

  // Step 2: for each event × each breakdown, navigate directly and download
  for (const eventName of eventNames) {
    for (const breakdown of breakdowns) {
      // Tell the background (ourselves) what to name the next download
      currentEventName     = eventName;
      currentBreakdownName = breakdown.name;
      currentExpId         = expId;

      const url =
        `https://create.roblox.com/dashboard/creations/experiences/${expId}` +
        `/analytics/custom?filter_AggregationType=Sum` +
        `&filter_CustomEventName=${encodeURIComponent(eventName)}` +
        `&annotation=PlaceVersion&annotation=ConfigVersion` +
        `&granularity=Daily${breakdown.suffix}`;

      await runInTab(url, expId, scrapeDownloadButton);
    }
  }
}

// ---------------------------------------------------------------------------
// Tab helpers
// ---------------------------------------------------------------------------

/** Navigate a tab to url, wait for load + delay, then run func. */
async function runInTab(url, expId, scriptFunc) {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  await chrome.tabs.update(tab.id, { url });

  return new Promise((resolve) => {
    chrome.tabs.onUpdated.addListener(function onUpdate(tabId, info) {
      if (tabId === tab.id && info.status === 'complete') {
        chrome.tabs.onUpdated.removeListener(onUpdate);
        // Wait for page content to render (charts take a few seconds)
        setTimeout(async () => {
          await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            func: scriptFunc,
            args: [expId]
          });
          resolve();
        }, 8000);
      }
    });
  });
}

/** Same as runInTab but returns the script's return value. */
async function runInTabWithResult(url, expId, scriptFunc) {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  await chrome.tabs.update(tab.id, { url });

  return new Promise((resolve) => {
    chrome.tabs.onUpdated.addListener(function onUpdate(tabId, info) {
      if (tabId === tab.id && info.status === 'complete') {
        chrome.tabs.onUpdated.removeListener(onUpdate);
        setTimeout(async () => {
          const results = await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            func: scriptFunc,
            args: [expId]
          });
          resolve(results?.[0]?.result ?? []);
        }, 8000);
      }
    });
  });
}

// ---------------------------------------------------------------------------
// Page scripts (injected into the Roblox tab)
// ---------------------------------------------------------------------------

/** Click all standard export/download buttons on the page. */
function scrapeStandardCSV() {
  const buttons = document.querySelectorAll(
    '[data-testid="chart-export-button"], [aria-label*="Export"], [data-testid="chart-download-button"]'
  );
  buttons.forEach(btn => btn.click());
}

/**
 * Wait for the chart-download-button to appear, then click it once.
 * Used for breakdown mode where each URL renders exactly one chart.
 */
async function scrapeDownloadButton() {
  const wait = (ms) => new Promise(res => setTimeout(res, ms));
  const deadline = Date.now() + 60000;

  while (Date.now() < deadline) {
    const btn = document.querySelector('[data-testid="chart-download-button"]');
    if (btn && btn.offsetParent !== null) {
      btn.click();
      return;
    }
    await wait(1000);
  }
  console.warn('Download button did not appear in time.');
}

/**
 * Opens the Custom Event Name dropdown, reads all option names, closes it,
 * and returns the list. Used to discover event names before iterating.
 */
async function scrapeEventNames() {
  const wait = (ms) => new Promise(res => setTimeout(res, ms));

  const label = Array.from(document.querySelectorAll('label'))
    .find(el => el.textContent.includes('Custom Event Name'));
  if (!label) return [];

  const openButton = label.parentElement.querySelector('button[aria-label="Open"]');
  if (!openButton) return [];

  openButton.click();
  await wait(1500);

  const options = Array.from(document.querySelectorAll('[role="listbox"] li'));
  const names = options.map(o => o.innerText.trim().replace(/\s+/g, '_'));

  // Close the dropdown
  document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
  await wait(500);

  return names;
}

/**
 * Original simple mode: click through the dropdown and download one CSV
 * per event (no breakdown splitting).
 */
async function scrapeCustomEventsSimple(expId) {
  const wait = (ms) => new Promise(res => setTimeout(res, ms));

  const label = Array.from(document.querySelectorAll('label'))
    .find(el => el.textContent.includes('Custom Event Name'));
  if (!label) return;

  const openButton = label.parentElement.querySelector('button[aria-label="Open"]');
  if (!openButton) return;

  openButton.click();
  await wait(1500);

  const options = Array.from(document.querySelectorAll('[role="listbox"] li'));

  for (let i = 0; i < options.length; i++) {
    const current = Array.from(document.querySelectorAll('[role="listbox"] li'));
    const eventName = current[i].innerText.trim().replace(/\s+/g, '_');

    current[i].click();
    await wait(4000);

    chrome.runtime.sendMessage({
      action: "SET_EVENT_NAME",
      eventName,
      breakdownName: '__simple__',
      expId
    });

    const btn = document.querySelector('[data-testid="chart-download-button"]');
    if (btn) btn.click();

    await wait(1500);
    document.querySelector('button[aria-label="Open"]')?.click();
    await wait(1000);
  }
}
